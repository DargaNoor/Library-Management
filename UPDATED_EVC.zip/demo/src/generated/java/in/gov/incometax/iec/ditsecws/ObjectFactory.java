
package in.gov.incometax.iec.ditsecws;

//import javax.xml.bind.JAXBElement;
//import javax.xml.bind.annotation.XmlElementDecl;
//import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlElementDecl;
import jakarta.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the in.gov.incometax.iec.ditsecws package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetBankAtmGenEvcDetails_QNAME = new QName("http://iec.incometax.gov.in/ditsecws", "getBankAtmGenEvcDetails");
    private final static QName _GetBankAtmGenEvcDetailsResponse_QNAME = new QName("http://iec.incometax.gov.in/ditsecws", "getBankAtmGenEvcDetailsResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: in.gov.incometax.iec.ditsecws
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetBankAtmGenEvcDetails }
     * 
     */
    public GetBankAtmGenEvcDetails createGetBankAtmGenEvcDetails() {
        return new GetBankAtmGenEvcDetails();
    }

    /**
     * Create an instance of {@link GetBankAtmGenEvcDetailsResponse }
     * 
     */
    public GetBankAtmGenEvcDetailsResponse createGetBankAtmGenEvcDetailsResponse() {
        return new GetBankAtmGenEvcDetailsResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBankAtmGenEvcDetails }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetBankAtmGenEvcDetails }{@code >}
     */
    @XmlElementDecl(namespace = "http://iec.incometax.gov.in/ditsecws", name = "getBankAtmGenEvcDetails")
    public JAXBElement<GetBankAtmGenEvcDetails> createGetBankAtmGenEvcDetails(GetBankAtmGenEvcDetails value) {
        return new JAXBElement<GetBankAtmGenEvcDetails>(_GetBankAtmGenEvcDetails_QNAME, GetBankAtmGenEvcDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBankAtmGenEvcDetailsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetBankAtmGenEvcDetailsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://iec.incometax.gov.in/ditsecws", name = "getBankAtmGenEvcDetailsResponse")
    public JAXBElement<GetBankAtmGenEvcDetailsResponse> createGetBankAtmGenEvcDetailsResponse(GetBankAtmGenEvcDetailsResponse value) {
        return new JAXBElement<GetBankAtmGenEvcDetailsResponse>(_GetBankAtmGenEvcDetailsResponse_QNAME, GetBankAtmGenEvcDetailsResponse.class, null, value);
    }

}
