
package in.gov.incometax.iec.ditsecws.request;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the in.gov.incometax.iec.ditsecws.request package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _BankAtmGenEvcRequest_QNAME = new QName("http://iec.incometax.gov.in/ditsecws/request", "BankAtmGenEvcRequest");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: in.gov.incometax.iec.ditsecws.request
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BankAtmGenEvcRequest }
     * 
     */
    public BankAtmGenEvcRequest createBankAtmGenEvcRequest() {
        return new BankAtmGenEvcRequest();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BankAtmGenEvcRequest }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link BankAtmGenEvcRequest }{@code >}
     */
    @XmlElementDecl(namespace = "http://iec.incometax.gov.in/ditsecws/request", name = "BankAtmGenEvcRequest")
    public JAXBElement<BankAtmGenEvcRequest> createBankAtmGenEvcRequest(BankAtmGenEvcRequest value) {
        return new JAXBElement<BankAtmGenEvcRequest>(_BankAtmGenEvcRequest_QNAME, BankAtmGenEvcRequest.class, null, value);
    }

}
