
package in.gov.incometax.iec.ditsecws.response;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the in.gov.incometax.iec.ditsecws.response package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _BankAtmGenEvcResponse_QNAME = new QName("http://iec.incometax.gov.in/ditsecws/response", "BankAtmGenEvcResponse");
    private final static QName _DitResponse_QNAME = new QName("http://iec.incometax.gov.in/ditsecws/response", "DitResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: in.gov.incometax.iec.ditsecws.response
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BankAtmGenEvcResponse }
     * 
     */
    public BankAtmGenEvcResponse createBankAtmGenEvcResponse() {
        return new BankAtmGenEvcResponse();
    }

    /**
     * Create an instance of {@link DitResponse }
     * 
     */
    public DitResponse createDitResponse() {
        return new DitResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BankAtmGenEvcResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link BankAtmGenEvcResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://iec.incometax.gov.in/ditsecws/response", name = "BankAtmGenEvcResponse")
    public JAXBElement<BankAtmGenEvcResponse> createBankAtmGenEvcResponse(BankAtmGenEvcResponse value) {
        return new JAXBElement<BankAtmGenEvcResponse>(_BankAtmGenEvcResponse_QNAME, BankAtmGenEvcResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DitResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DitResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://iec.incometax.gov.in/ditsecws/response", name = "DitResponse")
    public JAXBElement<DitResponse> createDitResponse(DitResponse value) {
        return new JAXBElement<DitResponse>(_DitResponse_QNAME, DitResponse.class, null, value);
    }

}
