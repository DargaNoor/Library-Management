package com.example.evc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import in.gov.incometax.iec.ditsecws.response.BankAtmGenEvcResponse;
import in.gov.incometax.iec.ditsecws.request.BankAtmGenEvcRequest;
import in.gov.incometax.iec.ditsecws.BankAtmGenEvcService_Service;
import in.gov.incometax.iec.ditsecws.BankAtmGenEvcService;

@SpringBootApplication
public class EvcApplication {

	public static void main(String[] args) {

		SpringApplication.run(EvcApplication.class, args);

		BankAtmGenEvcService_Service service = new BankAtmGenEvcService_Service(); // Create a Service object
		BankAtmGenEvcService  servicePort = service.getBankAtmGenEvcServicePort(); // Get the service port

		// Prepare your request object (replace with your specific data)
		BankAtmGenEvcRequest request = new BankAtmGenEvcRequest();
		request.setPan("?");
		request.setAtmId("12386899");
		request.setAtmCardNo("?");
		request.setBankAccNum("?");
		request.setIfsCode("SBIN0007990");
		request.setAtmAccessTime("?");
		request.setAccountName("?");
		request.setAccountType("?");
		request.setAccountStatus("?");
		request.setEmailId("?");
		request.setMobileNumber("?");
		System.out.println(request);
		// Send the request (assuming a method in Service_Service)
		BankAtmGenEvcResponse response = servicePort.getBankAtmGenEvcDetails(request);
		System.out.println(response);
	}

}
