
package in.gov.incometax.iec.ditsecws;

import org.apache.cxf.aegis.type.java5.XmlType;
import jakarta.xml.bind.annotation.XmlAccessType;
//import jakarta.xml.bind.annotation.XmlAccessorOrder;
//import javax.xml.bind.annotation.XmlAccessType;
//import javax.xml.bind.annotation.XmlAccessorType;
//import javax.xml.bind.annotation.XmlElement;
//import javax.xml.bind.annotation.XmlType;
import in.gov.incometax.iec.ditsecws.request.BankAtmGenEvcRequest;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;


/**
 * <p>Java class for getBankAtmGenEvcDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getBankAtmGenEvcDetails"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DitRequest" type="{http://iec.incometax.gov.in/ditsecws/request}BankAtmGenEvcRequest"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)

@XmlType(name = "getBankAtmGenEvcDetails")
public class GetBankAtmGenEvcDetails {

    @XmlElement(name = "DitRequest", required = true)
    protected BankAtmGenEvcRequest ditRequest;

    /**
     * Gets the value of the ditRequest property.
     * 
     * @return
     *     possible object is
     *     {@link BankAtmGenEvcRequest }
     *     
     */
    public BankAtmGenEvcRequest getDitRequest() {
        return ditRequest;
    }

    /**
     * Sets the value of the ditRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link BankAtmGenEvcRequest }
     *     
     */
    public void setDitRequest(BankAtmGenEvcRequest value) {
        this.ditRequest = value;
    }

}
