
package in.gov.incometax.iec.ditsecws.request;

import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;
import jakarta.xml.bind.annotation.XmlAccessType;

//import javax.xml.bind.annotation.XmlAccessType;
//import javax.xml.bind.annotation.XmlAccessorType;
//import javax.xml.bind.annotation.XmlAttribute;
//import javax.xml.bind.annotation.XmlElement;
//import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BankAtmGenEvcRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BankAtmGenEvcRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="pan" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="atmId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="atmCardNo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name=" " type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ifsCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="atmAccessTime" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="accountName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="accountType" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="accountStatus" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="emailId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="mobileNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="uniqueRequestId" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankAtmGenEvcRequest", propOrder = {
    "pan",
    "atmId",
    "atmCardNo",
    "bankAccNum",
    "ifsCode",
    "atmAccessTime",
    "accountName",
    "accountType",
    "accountStatus",
    "emailId",
    "mobileNumber"
})
public class BankAtmGenEvcRequest {

    @XmlElement(required = true)
    protected String pan;
    @XmlElement(required = true)
    protected String atmId;
    @XmlElement(required = true)
    protected String atmCardNo;
    @XmlElement(required = true)
    protected String bankAccNum;
    @XmlElement(required = true)
    protected String ifsCode;
    @XmlElement(required = true)
    protected String atmAccessTime;
    @XmlElement(required = true)
    protected String accountName;
    @XmlElement(required = true)
    protected String accountType;
    @XmlElement(required = true)
    protected String accountStatus;
    @XmlElement(required = true)
    protected String emailId;
    @XmlElement(required = true)
    protected String mobileNumber;
    @XmlAttribute(name = "uniqueRequestId", required = true)
    protected String uniqueRequestId;

    /**
     * Gets the value of the pan property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPan() {
        return pan;
    }

    /**
     * Sets the value of the pan property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPan(String value) {
        this.pan = value;
    }

    /**
     * Gets the value of the atmId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAtmId() {
        return atmId;
    }

    /**
     * Sets the value of the atmId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAtmId(String value) {
        this.atmId = value;
    }

    /**
     * Gets the value of the atmCardNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAtmCardNo() {
        return atmCardNo;
    }

    /**
     * Sets the value of the atmCardNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAtmCardNo(String value) {
        this.atmCardNo = value;
    }

    /**
     * Gets the value of the bankAccNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankAccNum() {
        return bankAccNum;
    }

    /**
     * Sets the value of the bankAccNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAccNum(String value) {
        this.bankAccNum = value;
    }

    /**
     * Gets the value of the ifsCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIfsCode() {
        return ifsCode;
    }

    /**
     * Sets the value of the ifsCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIfsCode(String value) {
        this.ifsCode = value;
    }

    /**
     * Gets the value of the atmAccessTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAtmAccessTime() {
        return atmAccessTime;
    }

    /**
     * Sets the value of the atmAccessTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAtmAccessTime(String value) {
        this.atmAccessTime = value;
    }

    /**
     * Gets the value of the accountName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountName() {
        return accountName;
    }

    /**
     * Sets the value of the accountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountName(String value) {
        this.accountName = value;
    }

    /**
     * Gets the value of the accountType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountType() {
        return accountType;
    }

    /**
     * Sets the value of the accountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountType(String value) {
        this.accountType = value;
    }

    /**
     * Gets the value of the accountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountStatus() {
        return accountStatus;
    }

    /**
     * Sets the value of the accountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountStatus(String value) {
        this.accountStatus = value;
    }

    /**
     * Gets the value of the emailId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * Sets the value of the emailId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailId(String value) {
        this.emailId = value;
    }

    /**
     * Gets the value of the mobileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * Sets the value of the mobileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobileNumber(String value) {
        this.mobileNumber = value;
    }

    /**
     * Gets the value of the uniqueRequestId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniqueRequestId() {
        return uniqueRequestId;
    }

    /**
     * Sets the value of the uniqueRequestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniqueRequestId(String value) {
        this.uniqueRequestId = value;
    }

}
